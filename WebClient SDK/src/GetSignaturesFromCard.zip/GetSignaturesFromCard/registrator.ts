import { ExtensionContainer, ExtensionStage } from 'tessa/extensions';
import { ODIncomingStamp } from './ODIncomingStampFileExtension';

ExtensionContainer.instance.registerExtension({
  extension: ODIncomingStamp,
  stage: ExtensionStage.BeforePlatform
});