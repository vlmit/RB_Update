//import { FileControlExtension, IFileControlExtensionContext } from 'tessa/ui/files';
import { UIContext, MenuAction, showLoadingOverlay,showNotEmpty, showMessage } from 'tessa/ui';
import { CardRequest, CardService } from 'tessa/cards/service';
import { Card } from 'tessa/cards';
import { DotNetType, createTypedField } from 'tessa/platform';
import { FileExtension, IFileExtensionContext } from 'tessa/ui/files';



export class ODIncomingStamp extends FileExtension {
  public async openingMenu(context: IFileExtensionContext) {
    //let uiContext = UIContext.current;
    //let editor = uiContext.cardEditor;
    //let card: Card = context.control.model.card;
    let card: Card = context.control.model.card;
    const file = context.file.model;
    // Добавляем пункт меню для получения файлов
    
    context.actions.push(
        new MenuAction(
          'SignAll',
          'Проставить регистрационный штамп',
          "ta icon-thin-254",
          async () => {
            const editor = UIContext.current.cardEditor;
            if (!editor
            ) {
              return;
            }
  
            
  
            showLoadingOverlay(async (splashResolve) => {
              //await editor.saveCard();
              let getIncomingStampRequest = new CardRequest();
              getIncomingStampRequest.requestType = "73f8c4a9-af21-48c3-b63f-2d6476c94e11";
              getIncomingStampRequest.info["cardID"] = createTypedField(card.id, DotNetType.Guid);
              getIncomingStampRequest.info["versionRowID"] = createTypedField(file.lastVersion.id, DotNetType.Guid);
              getIncomingStampRequest.info["fileName"] = createTypedField(file.name, DotNetType.String);
              
              let getSignaturesResponse = await CardService.instance.request(getIncomingStampRequest);
              if (!getSignaturesResponse.validationResult.isSuccessful) {
                await showNotEmpty(getSignaturesResponse.validationResult.build());
                showMessage('Ошибка получения штампа, сохраните карточку и попробуйте снова!');
               
                return;
              }
              await editor.saveCard();
             
              splashResolve;
            });
          },
          null,
          context.files.length > 2 || file.getExtension() !== 'pdf'
      ));
  }

  
}
/*function downloadBase64File(contentBase64, fileName) {
  const linkSource = `data:archive/zip;base64,${contentBase64}`;
  const downloadLink = document.createElement('a');
  document.body.appendChild(downloadLink);
  
  downloadLink.href = linkSource;
  downloadLink.target = '_self';
  downloadLink.download = fileName;
  downloadLink.click(); 
}*/